/* Global Variables */

// const { response } = require("express");

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+1 + '.' + d.getDate() + '.' + d.getFullYear();

let baseURL = 'http://api.openweathermap.org/data/2.5/weather?zip='

const apiKey = '&appid=e8673eb78f561fea11cbd6fb3634572b&units=imperial';

document.getElementById("generate").addEventListener('click', performAction);

function performAction(e) {
    
    const zipcode = document.getElementById('zip').value;
    const feelings = document.getElementById('feelings').value;

    const countrycode = ",US"

    getweather(baseURL, zipcode, countrycode, apiKey)
        .then(function(data) {
            postdata('/postdata', { temperature: data.main.temp, feelings: feelings, date: newDate })
               /*  .then(function(data) {
                    const de = document.querySelector("#date")
                    de.innerHTML = data.date

                    const fe = document.querySelector("#temp")
                    fe.innerHTML = data.temperature

                    const ce = document.querySelector("#content")
                    ce.innerHTML = data.feelings


                }) */
                /* .then(function(data){
                    console.log("within then" + data)
                    retrieveData()

                }) */
        });

}

const getweather = async(baseURL, zipode, countrycode, key) => {

    const res = await fetch(baseURL + zipode + countrycode + key)
    try {

        const data = await res.json();
        console.log(data)
        return data;
    } catch (error) {
        console.log("error", error);
        // appropriately handle the error
    }

}

const postdata = async(url, data) => {
    console.log(data)
    console.log("After ")
    const response = await fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });
    try {
        const newData = await response.json();
        console.log(newData);
        retrieveData()
    } catch (error) {
        console.log("error " + error);
        //return new Promise.reject("Failed")

    }
}

/* Function to GET Project Data */
const retrieveData = async () =>{
    
    const request = await fetch('/all');
    try {
    // Transform into JSON
    const allData = await request.json()
    console.log(allData)
    // Write updated data to DOM elements
    
    num = parseFloat(allData.temperature)
    document.getElementById('temp').innerHTML = num+ ' ferenhit';
    document.getElementById('content').innerHTML = allData.feelings;
    document.getElementById("date").innerHTML =allData.date;

    }
    catch(error) {
      console.log("error", error);
      // appropriately handle the error
    }
   }